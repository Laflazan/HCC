const team = [
  {
    name: "Victoria Sterling",
    role: "Managing Partner",
    expertise: ["Corporate M&A", "Private Equity"],
    image: "VS",
  },
  {
    name: "Alexander Chen",
    role: "Senior Partner",
    expertise: ["Dispute Resolution", "Arbitration"],
    image: "AC",
  },
  {
    name: "Margaret Blackwood",
    role: "Partner",
    expertise: ["Intellectual Property", "Technology"],
    image: "MB",
  },
  {
    name: "James Morrison",
    role: "Partner",
    expertise: ["Finance Law", "Banking"],
    image: "JM",
  },
  {
    name: "Elena Rodriguez",
    role: "Partner",
    expertise: ["Competition Law", "EU Regulation"],
    image: "ER",
  },
  {
    name: "David Kim",
    role: "Senior Associate",
    expertise: ["Data Protection", "Privacy"],
    image: "DK",
  },
]

export function Team() {
  return (
    <section id="team" className="py-24 lg:py-32 bg-background">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto">
          <div className="flex justify-center mb-8">
            <div className="h-px w-16 bg-gold" />
          </div>
          <h2 className="font-serif text-4xl md:text-5xl font-medium text-foreground tracking-tight">
            Our People
          </h2>
          <p className="mt-6 text-lg text-muted-foreground leading-relaxed">
            A team of distinguished legal professionals committed to delivering 
            exceptional results for our clients.
          </p>
        </div>
        
        {/* Team grid */}
        <div className="mt-16 grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {team.map((member) => (
            <div
              key={member.name}
              className="group relative overflow-hidden bg-secondary"
            >
              {/* Portrait placeholder */}
              <div className="aspect-[3/4] bg-muted flex items-center justify-center">
                <span className="font-serif text-4xl text-muted-foreground/50">
                  {member.image}
                </span>
              </div>
              
              {/* Overlay on hover */}
              <div className="absolute inset-0 bg-foreground/90 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6">
                <div className="text-background">
                  <h3 className="font-serif text-xl font-medium">
                    {member.name}
                  </h3>
                  <p className="mt-1 text-gold text-sm">
                    {member.role}
                  </p>
                  <div className="mt-4 flex flex-wrap gap-2">
                    {member.expertise.map((tag) => (
                      <span
                        key={tag}
                        className="text-xs text-background/70 border border-background/20 px-2 py-1"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
              
              {/* Default info */}
              <div className="p-6 bg-background border-t border-border group-hover:opacity-0 transition-opacity">
                <h3 className="font-serif text-lg font-medium text-foreground">
                  {member.name}
                </h3>
                <p className="mt-1 text-sm text-muted-foreground">
                  {member.role}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
