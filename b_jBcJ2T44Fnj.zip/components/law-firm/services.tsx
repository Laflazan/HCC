import { Building2, Scale, Lightbulb, Shield, Gavel, Landmark } from "lucide-react"

const services = [
  {
    icon: Building2,
    title: "Corporate & M&A",
    description: "Strategic advisory on mergers, acquisitions, joint ventures, and corporate restructuring across borders.",
  },
  {
    icon: Scale,
    title: "Dispute Resolution",
    description: "Comprehensive litigation and arbitration services, representing clients in complex commercial disputes.",
  },
  {
    icon: Lightbulb,
    title: "Intellectual Property",
    description: "Protection and enforcement of patents, trademarks, copyrights, and trade secrets worldwide.",
  },
  {
    icon: Shield,
    title: "Data Protection",
    description: "Compliance with global data privacy regulations including GDPR, CCPA, and emerging frameworks.",
  },
  {
    icon: Gavel,
    title: "Competition Law",
    description: "Antitrust guidance, merger control filings, and defense against regulatory investigations.",
  },
  {
    icon: Landmark,
    title: "Finance Law",
    description: "Banking, capital markets, project finance, and regulatory compliance for financial institutions.",
  },
]

export function Services() {
  return (
    <section id="services" className="py-24 lg:py-32 bg-background">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto">
          <div className="flex justify-center mb-8">
            <div className="h-px w-16 bg-gold" />
          </div>
          <h2 className="font-serif text-4xl md:text-5xl font-medium text-foreground tracking-tight">
            Our Practice Areas
          </h2>
          <p className="mt-6 text-lg text-muted-foreground leading-relaxed">
            Delivering excellence across a comprehensive range of legal disciplines, 
            tailored to meet the complex needs of our global clientele.
          </p>
        </div>
        
        {/* Services grid */}
        <div className="mt-16 grid md:grid-cols-2 lg:grid-cols-3 gap-px bg-border">
          {services.map((service) => (
            <div
              key={service.title}
              className="bg-background p-8 lg:p-10 group hover:bg-secondary transition-colors duration-300"
            >
              <service.icon className="h-8 w-8 text-gold" strokeWidth={1.5} />
              <h3 className="mt-6 font-serif text-xl font-medium text-foreground">
                {service.title}
              </h3>
              <p className="mt-4 text-muted-foreground leading-relaxed">
                {service.description}
              </p>
              <div className="mt-6 h-px w-0 bg-gold group-hover:w-12 transition-all duration-300" />
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
