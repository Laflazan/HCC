const stats = [
  { value: "40+", label: "Years Experience" },
  { value: "70+", label: "Legal Experts" },
  { value: "25+", label: "Countries Served" },
  { value: "500+", label: "Clients Worldwide" },
]

export function About() {
  return (
    <section id="about" className="py-24 lg:py-32 bg-secondary">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Content */}
          <div>
            <div className="h-px w-16 bg-gold mb-8" />
            <h2 className="font-serif text-4xl md:text-5xl font-medium text-foreground tracking-tight">
              A Full-Service
              <br />
              <span className="text-gold">International Law Firm</span>
            </h2>
            <p className="mt-8 text-lg text-muted-foreground leading-relaxed">
              Sterling & Associates is a leading international law firm providing 
              comprehensive legal services across multiple jurisdictions. Our team 
              of experienced attorneys delivers strategic, commercially-focused 
              solutions for complex legal challenges.
            </p>
            <p className="mt-6 text-lg text-muted-foreground leading-relaxed">
              With deep expertise across key practice areas and industries, we 
              serve as trusted advisors to corporations, financial institutions, 
              governments, and high-net-worth individuals around the world.
            </p>
            
            {/* Trust indicators */}
            <div className="mt-10 flex flex-wrap gap-6">
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <div className="h-2 w-2 bg-gold" />
                <span>Full-service law firm</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <div className="h-2 w-2 bg-gold" />
                <span>International expertise</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <div className="h-2 w-2 bg-gold" />
                <span>Trusted by global clients</span>
              </div>
            </div>
          </div>
          
          {/* Stats grid */}
          <div className="grid grid-cols-2 gap-8">
            {stats.map((stat) => (
              <div key={stat.label} className="bg-background p-8 border border-border">
                <div className="font-serif text-4xl md:text-5xl font-medium text-foreground">
                  {stat.value}
                </div>
                <div className="mt-2 text-sm text-muted-foreground uppercase tracking-wider">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
