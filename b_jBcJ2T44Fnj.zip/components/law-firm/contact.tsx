"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { MapPin, Phone, Mail, Clock } from "lucide-react"

const offices = [
  {
    city: "New York",
    address: "One World Trade Center, Suite 4800",
    phone: "+1 (212) 555-0100",
  },
  {
    city: "London",
    address: "30 St Mary Axe, Level 22",
    phone: "+44 20 7555 0100",
  },
  {
    city: "Singapore",
    address: "Marina Bay Financial Centre, Tower 1",
    phone: "+65 6555 0100",
  },
]

export function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    company: "",
    message: "",
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Handle form submission
    console.log(formData)
  }

  return (
    <section id="contact" className="py-24 lg:py-32 bg-background">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16">
          {/* Contact info */}
          <div>
            <div className="h-px w-16 bg-gold mb-8" />
            <h2 className="font-serif text-4xl md:text-5xl font-medium text-foreground tracking-tight">
              Get in Touch
            </h2>
            <p className="mt-6 text-lg text-muted-foreground leading-relaxed">
              Contact us to discuss how we can assist with your legal needs. 
              Our team is ready to provide strategic counsel tailored to your objectives.
            </p>
            
            {/* Contact details */}
            <div className="mt-10 space-y-6">
              <div className="flex items-start gap-4">
                <Mail className="h-5 w-5 text-gold mt-1" />
                <div>
                  <p className="text-sm text-muted-foreground uppercase tracking-wider">Email</p>
                  <p className="mt-1 text-foreground">contact@sterlinglaw.com</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <Clock className="h-5 w-5 text-gold mt-1" />
                <div>
                  <p className="text-sm text-muted-foreground uppercase tracking-wider">Hours</p>
                  <p className="mt-1 text-foreground">Monday – Friday, 9:00 AM – 6:00 PM</p>
                </div>
              </div>
            </div>
            
            {/* Offices */}
            <div className="mt-12">
              <h3 className="font-serif text-xl font-medium text-foreground">Our Offices</h3>
              <div className="mt-6 space-y-6">
                {offices.map((office) => (
                  <div key={office.city} className="flex items-start gap-4 pb-6 border-b border-border last:border-0">
                    <MapPin className="h-5 w-5 text-gold mt-1 flex-shrink-0" />
                    <div>
                      <p className="font-medium text-foreground">{office.city}</p>
                      <p className="mt-1 text-sm text-muted-foreground">{office.address}</p>
                      <p className="mt-1 text-sm text-muted-foreground flex items-center gap-2">
                        <Phone className="h-3 w-3" />
                        {office.phone}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          
          {/* Contact form */}
          <div className="bg-secondary p-8 lg:p-12">
            <h3 className="font-serif text-2xl font-medium text-foreground">
              Send us a Message
            </h3>
            <p className="mt-2 text-muted-foreground">
              We&apos;ll respond within one business day.
            </p>
            
            <form onSubmit={handleSubmit} className="mt-8 space-y-6">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-foreground">
                  Full Name
                </label>
                <Input
                  id="name"
                  type="text"
                  required
                  className="mt-2 bg-background border-border"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                />
              </div>
              
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-foreground">
                  Email Address
                </label>
                <Input
                  id="email"
                  type="email"
                  required
                  className="mt-2 bg-background border-border"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                />
              </div>
              
              <div>
                <label htmlFor="company" className="block text-sm font-medium text-foreground">
                  Company / Organization
                </label>
                <Input
                  id="company"
                  type="text"
                  className="mt-2 bg-background border-border"
                  value={formData.company}
                  onChange={(e) => setFormData({ ...formData, company: e.target.value })}
                />
              </div>
              
              <div>
                <label htmlFor="message" className="block text-sm font-medium text-foreground">
                  How Can We Help?
                </label>
                <Textarea
                  id="message"
                  required
                  rows={5}
                  className="mt-2 bg-background border-border resize-none"
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                />
              </div>
              
              <Button
                type="submit"
                size="lg"
                className="w-full bg-foreground text-background hover:bg-foreground/90"
              >
                Submit Inquiry
              </Button>
              
              <p className="text-xs text-muted-foreground text-center">
                By submitting this form, you agree to our privacy policy and terms of service.
              </p>
            </form>
          </div>
        </div>
      </div>
    </section>
  )
}
