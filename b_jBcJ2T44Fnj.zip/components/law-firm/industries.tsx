"use client"

import { useRef } from "react"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"

const industries = [
  {
    name: "Technology",
    description: "Supporting tech companies from startups to global enterprises",
  },
  {
    name: "Energy",
    description: "Advisory across oil, gas, renewables, and power sectors",
  },
  {
    name: "Healthcare",
    description: "Regulatory, M&A, and compliance for life sciences",
  },
  {
    name: "Finance",
    description: "Banks, funds, and financial services regulation",
  },
  {
    name: "Construction",
    description: "Project development, disputes, and infrastructure",
  },
  {
    name: "Manufacturing",
    description: "Supply chain, trade, and industrial operations",
  },
]

export function Industries() {
  const scrollRef = useRef<HTMLDivElement>(null)

  const scroll = (direction: "left" | "right") => {
    if (scrollRef.current) {
      const scrollAmount = 320
      scrollRef.current.scrollBy({
        left: direction === "left" ? -scrollAmount : scrollAmount,
        behavior: "smooth",
      })
    }
  }

  return (
    <section id="industries" className="py-24 lg:py-32 bg-foreground">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-8">
          <div>
            <div className="h-px w-16 bg-gold mb-8" />
            <h2 className="font-serif text-4xl md:text-5xl font-medium text-background tracking-tight">
              Industries We Serve
            </h2>
            <p className="mt-6 text-lg text-background/70 max-w-xl leading-relaxed">
              Deep sector expertise enabling us to deliver informed, strategic counsel 
              across diverse industries.
            </p>
          </div>
          
          {/* Navigation arrows */}
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="icon"
              className="border-background/20 text-background hover:bg-background hover:text-foreground"
              onClick={() => scroll("left")}
            >
              <ChevronLeft className="h-5 w-5" />
              <span className="sr-only">Scroll left</span>
            </Button>
            <Button
              variant="outline"
              size="icon"
              className="border-background/20 text-background hover:bg-background hover:text-foreground"
              onClick={() => scroll("right")}
            >
              <ChevronRight className="h-5 w-5" />
              <span className="sr-only">Scroll right</span>
            </Button>
          </div>
        </div>
        
        {/* Horizontal scroll */}
        <div
          ref={scrollRef}
          className="mt-12 flex gap-6 overflow-x-auto pb-4 scrollbar-hide"
          style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
        >
          {industries.map((industry) => (
            <div
              key={industry.name}
              className="flex-shrink-0 w-72 bg-background/5 border border-background/10 p-8 group hover:bg-background/10 transition-colors"
            >
              <h3 className="font-serif text-2xl font-medium text-background">
                {industry.name}
              </h3>
              <p className="mt-4 text-background/60 leading-relaxed">
                {industry.description}
              </p>
              <div className="mt-6 h-px w-0 bg-gold group-hover:w-full transition-all duration-500" />
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
