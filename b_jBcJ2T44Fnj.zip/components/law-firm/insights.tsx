import Link from "next/link"
import { ArrowRight } from "lucide-react"

const insights = [
  {
    date: "March 28, 2026",
    category: "Corporate",
    title: "Navigating Cross-Border M&A in an Era of Heightened Regulatory Scrutiny",
    excerpt: "Analysis of recent regulatory developments and strategic considerations for international transactions.",
  },
  {
    date: "March 15, 2026",
    category: "Data Protection",
    title: "Global Data Privacy Trends: What Businesses Need to Know in 2026",
    excerpt: "A comprehensive overview of emerging privacy regulations and compliance strategies.",
  },
  {
    date: "March 8, 2026",
    category: "Dispute Resolution",
    title: "Arbitration Clause Best Practices for International Commercial Contracts",
    excerpt: "Key drafting considerations to ensure effective dispute resolution mechanisms.",
  },
]

export function Insights() {
  return (
    <section id="insights" className="py-24 lg:py-32 bg-secondary">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-8">
          <div>
            <div className="h-px w-16 bg-gold mb-8" />
            <h2 className="font-serif text-4xl md:text-5xl font-medium text-foreground tracking-tight">
              Insights & News
            </h2>
            <p className="mt-6 text-lg text-muted-foreground max-w-xl leading-relaxed">
              Thought leadership and legal analysis from our team of experts.
            </p>
          </div>
          
          <Link
            href="#"
            className="inline-flex items-center gap-2 text-sm font-medium text-foreground hover:text-gold transition-colors group"
          >
            View All Insights
            <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
        
        {/* Articles grid */}
        <div className="mt-12 grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {insights.map((article) => (
            <article
              key={article.title}
              className="bg-background border border-border p-8 group hover:border-gold/30 transition-colors"
            >
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <span>{article.date}</span>
                <span className="h-1 w-1 bg-gold" />
                <span className="text-gold">{article.category}</span>
              </div>
              
              <h3 className="mt-6 font-serif text-xl font-medium text-foreground leading-tight group-hover:text-gold transition-colors">
                <Link href="#">{article.title}</Link>
              </h3>
              
              <p className="mt-4 text-muted-foreground leading-relaxed line-clamp-3">
                {article.excerpt}
              </p>
              
              <Link
                href="#"
                className="mt-6 inline-flex items-center gap-2 text-sm font-medium text-foreground hover:text-gold transition-colors"
              >
                Read More
                <ArrowRight className="h-4 w-4" />
              </Link>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}
